// controller.js
let data = require("./data");

// --- Melihat Data ---
function lihatData() {
  console.log("=== Daftar Data ===");
  data.map((item, index) => {
    console.log(`${index + 1}. ${item.nama} - ${item.umur} tahun - ${item.alamat} - ${item.email}`);
  });
}

// --- Menambah Data (push minimal 2 sekaligus) ---
function tambahData() {
  data.push(
    { nama: "Yudi", umur: 26, alamat: "Pontianak", email: "yudi@gmail.com" },
    { nama: "Salsa", umur: 20, alamat: "Cirebon", email: "salsa@gmail.com" }
  );
}

// --- Hapus Data ---
function hapusData(index) {
  if (index >= 0 && index < data.length) {
    data.splice(index, 1);
    console.log(`Data ke-${index + 1} berhasil dihapus.`);
  } else {
    console.log("Index tidak valid!");
  }
}

// --- Demo ---
console.log("Data awal:");
lihatData();

tambahData();
console.log("\nSetelah tambah 2 data:");
lihatData();

hapusData(0);
console.log("\nSetelah hapus data pertama:");
lihatData();
