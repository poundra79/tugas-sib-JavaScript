// data.js
let data = [
  { nama: "Fahmi", umur: 22, alamat: "BSD", email: "fahmi@gmail.com" },
  { nama: "Ariq", umur: 20, alamat: "Pamulang", email: "ariq@gmail.com" },
  { nama: "Rafa", umur: 19, alamat: "Tiga Raksa", email: "rafa@gmail.com" },
  { nama: "Dimas", umur: 21, alamat: "Gunung Sindur", email: "dimas@gmail.com" },
  { nama: "Fahri", umur: 24, alamat: "Ciater", email: "fahri@gmail.com" },
  { nama: "Janis", umur: 20, alamat: "Yogyakarta", email: "janis@gmail.com" },
  { nama: "Janu", umur: 23, alamat: "Yogyakarta", email: "janu@gmail.com" },
  { nama: "Fajar", umur: 25, alamat: "Palembang", email: "fajar@gmail.com" },
  { nama: "Lina", umur: 22, alamat: "Makassar", email: "lina@gmail.com" },
  { nama: "Tono", umur: 21, alamat: "Bali", email: "tono@gmail.com" }
];

module.exports = data;
